function removeBG(){
 alert("API key required! Replace in script.js to enable actual background removal.");
}
